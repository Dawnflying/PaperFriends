---
title: removeFromSelection
name: multiple-selection-remove-from-selection
---

Remove this node from the selection.

{% highlight js %}
var node = $('#tree1').tree('getNodeById', 123);
$('#tree1').tree('removeFromSelection', node);
{% endhighlight %}
