---
title: getNextSibling
name: node-functions-getnextsibling
---

Get the next sibling of this node. Returns a node or null.

{% highlight js %}
var node = node.getNextSibling();
{% endhighlight %}
