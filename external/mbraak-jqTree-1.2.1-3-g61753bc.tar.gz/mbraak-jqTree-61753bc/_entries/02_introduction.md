---
title: Introduction
name: introduction
---

JqTree is a jQuery widget for displaying a **tree structure** in html. It supports **json data**, loading via
**ajax** and **drag-and-drop**.

[![Bower version](https://img.shields.io/bower/v/jqtree.svg)](https://mbraak.github.io/jqTree/) [![NPM version](https://img.shields.io/npm/v/jqtree.svg)](https://www.npmjs.com/package/jqtree)
