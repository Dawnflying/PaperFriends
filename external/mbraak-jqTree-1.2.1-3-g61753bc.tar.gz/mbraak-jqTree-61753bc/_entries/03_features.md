---
title: Features
name: features
---

* Create a tree from JSON data
* Load data using ajax
* Drag and drop
* Saves the state
* Keyboard support
* Lazy loading
* Works on ie8+, firefox 3.6+, chrome and safari
* Written in Coffeescript

The project is [hosted on github](https://github.com/mbraak/jqTree), has a [test suite](test/test.html).
