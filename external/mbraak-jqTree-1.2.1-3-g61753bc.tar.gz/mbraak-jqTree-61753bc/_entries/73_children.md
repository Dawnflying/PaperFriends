---
title: children
name: node-functions-children
---

You can access the children of a node using the **children** property.

{% highlight js %}
for (var i=0; i < node.children.length; i++) {
    var child = node.children[i];
}
{% endhighlight %}
